"""
infer.py — Run a trained EcoVision checkpoint on new image(s).

Usage:
    python infer.py --checkpoint checkpoints/best_model.pt --image path/to/photo.jpg
    python infer.py --checkpoint checkpoints/best_model.pt --image_dir path/to/folder/
"""

import argparse
import glob
import os

import torch
import torch.nn.functional as F
from PIL import Image

from dataset import build_transforms
from model import build_model


def load_model(checkpoint_path: str, device: torch.device):
    ckpt = torch.load(checkpoint_path, map_location=device)
    model = build_model(num_classes=len(ckpt["class_names"]), backbone=ckpt["backbone"], freeze_backbone=False)
    model.load_state_dict(ckpt["model_state"])
    model.to(device)
    model.eval()
    return model, ckpt["class_names"]


@torch.no_grad()
def classify_image(model, class_names, image_path: str, device: torch.device, topk: int = 3):
    transform = build_transforms(train=False)
    img = Image.open(image_path).convert("RGB")
    tensor = transform(img).unsqueeze(0).to(device)

    logits = model(tensor)
    probs = F.softmax(logits, dim=1)[0]
    top_probs, top_idxs = probs.topk(min(topk, len(class_names)))

    results = [(class_names[i], float(p)) for p, i in zip(top_probs, top_idxs)]
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--image", type=str, help="Path to a single image")
    parser.add_argument("--image_dir", type=str, help="Path to a directory of images")
    parser.add_argument("--topk", type=int, default=3)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, class_names = load_model(args.checkpoint, device)
    print(f"Loaded model on {device}. Classes: {class_names}")

    paths = []
    if args.image:
        paths = [args.image]
    elif args.image_dir:
        for ext in ("*.jpg", "*.jpeg", "*.png"):
            paths.extend(glob.glob(os.path.join(args.image_dir, ext)))
    else:
        raise SystemExit("Provide --image or --image_dir")

    for path in paths:
        results = classify_image(model, class_names, path, device, topk=args.topk)
        print(f"\n{os.path.basename(path)}")
        for cls, prob in results:
            print(f"  {cls:12s} {prob * 100:5.1f}%")


if __name__ == "__main__":
    main()
