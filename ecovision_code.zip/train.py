"""
train.py — GPU-accelerated training loop for EcoVision.

Usage:
    python train.py --data_dir ./data --epochs 15 --batch_size 32 --backbone resnet50

Key GPU-acceleration features:
  * Runs on CUDA automatically if available (falls back to CPU/MPS otherwise)
  * Automatic Mixed Precision (AMP) — ~2x faster training, lower VRAM use
  * Two-stage transfer learning: (1) train the new head with backbone frozen,
    (2) unfreeze the last layers and fine-tune at a lower LR
"""

import argparse
import time
import json
import os

import torch
import torch.nn as nn
from torch.amp import autocast, GradScaler

from dataset import get_dataloaders
from model import build_model, unfreeze_last_n_layers


def get_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def run_epoch(model, loader, criterion, optimizer, device, scaler, train: bool):
    model.train() if train else model.eval()
    total_loss, correct, total = 0.0, 0, 0

    for images, labels in loader:
        images, labels = images.to(device, non_blocking=True), labels.to(device, non_blocking=True)

        if train:
            optimizer.zero_grad(set_to_none=True)

        with torch.set_grad_enabled(train):
            with autocast(device_type=device.type, enabled=(device.type == "cuda")):
                outputs = model(images)
                loss = criterion(outputs, labels)

            if train:
                if scaler is not None:
                    scaler.scale(loss).backward()
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    loss.backward()
                    optimizer.step()

        total_loss += loss.item() * images.size(0)
        preds = outputs.argmax(dim=1)
        correct += (preds == labels).sum().item()
        total += images.size(0)

    return total_loss / total, correct / total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="./data")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--backbone", type=str, default="resnet50",
                         choices=["resnet50", "efficientnet_b0", "mobilenet_v3_large"])
    parser.add_argument("--finetune_epoch", type=int, default=6,
                         help="Epoch at which to unfreeze backbone layers for stage-2 fine-tuning")
    parser.add_argument("--out_dir", type=str, default="./checkpoints")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    device = get_device()
    print(f"Using device: {device}")

    train_loader, val_loader, class_names = get_dataloaders(args.data_dir, args.batch_size)
    print(f"Classes ({len(class_names)}): {class_names}")

    model = build_model(num_classes=len(class_names), backbone=args.backbone, freeze_backbone=True)
    model.to(device)

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    best_val_acc = 0.0
    history = []

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()

        if epoch == args.finetune_epoch:
            print(">> Unfreezing backbone for stage-2 fine-tuning")
            unfreeze_last_n_layers(model, n=30)
            optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr / 10)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs - epoch + 1)

        train_loss, train_acc = run_epoch(model, train_loader, criterion, optimizer, device, scaler, train=True)
        val_loss, val_acc = run_epoch(model, val_loader, criterion, optimizer, device, scaler, train=False)
        scheduler.step()

        dt = time.time() - t0
        print(f"Epoch {epoch:02d}/{args.epochs} | "
              f"train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
              f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} | {dt:.1f}s")

        history.append({"epoch": epoch, "train_loss": train_loss, "train_acc": train_acc,
                         "val_loss": val_loss, "val_acc": val_acc, "seconds": dt})

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save({
                "model_state": model.state_dict(),
                "class_names": class_names,
                "backbone": args.backbone,
                "val_acc": val_acc,
            }, os.path.join(args.out_dir, "best_model.pt"))
            print(f"  ✓ New best model saved (val_acc={val_acc:.4f})")

    with open(os.path.join(args.out_dir, "history.json"), "w") as f:
        json.dump(history, f, indent=2)

    print(f"\nTraining complete. Best val accuracy: {best_val_acc:.4f}")
    print(f"Model + history saved to {args.out_dir}/")


if __name__ == "__main__":
    main()
