# EcoVision — GPU-Accelerated Waste Image Classification

Transfer-learning pipeline that classifies waste images into categories
(e.g. cardboard, glass, metal, paper, plastic, trash) using a pretrained
CNN backbone fine-tuned on GPU.

## Setup

```bash
pip install -r requirements.txt
```

## 1. Prepare your data

Download a waste dataset such as:
- **TrashNet** (~2,500 images, 6 classes) — https://github.com/garythung/trashnet
- **Kaggle "Garbage Classification"** dataset (~15,000 images, 12 classes)
- **TACO** (Trash Annotations in Context) for detection-style / more real-world images

If your data is a single folder of `class/*.jpg` subfolders, split it first:

```python
from dataset import split_dataset
split_dataset("raw_data/", "data/", val_frac=0.2)
```

This produces `data/train/<class>/` and `data/val/<class>/`.

## 2. Train (GPU-accelerated)

```bash
python train.py --data_dir ./data --epochs 15 --batch_size 32 --backbone resnet50
```

- Automatically uses CUDA if available, with mixed-precision (AMP) for ~2x speedup.
- Two-stage transfer learning: trains a new classifier head first (backbone frozen),
  then unfreezes the last backbone layers for fine-tuning at a lower learning rate
  (controlled by `--finetune_epoch`).
- Best checkpoint (by validation accuracy) is saved to `checkpoints/best_model.pt`.

Swap `--backbone` between `resnet50` (best accuracy), `efficientnet_b0` (good
balance), or `mobilenet_v3_large` (fastest, best for edge/mobile deployment).

## 3. Run inference

```bash
python infer.py --checkpoint checkpoints/best_model.pt --image sample.jpg
python infer.py --checkpoint checkpoints/best_model.pt --image_dir ./test_images/
```

## Files

| File | Purpose |
|---|---|
| `dataset.py` | Data loading, augmentation, train/val splitting |
| `model.py` | Model architectures (ResNet50 / EfficientNet-B0 / MobileNetV3) |
| `train.py` | GPU-accelerated training loop (AMP, two-stage fine-tuning) |
| `infer.py` | Load a checkpoint and classify new images |

## Expected results

On TrashNet-style 6-class data with ResNet50, this pipeline typically reaches
~90-94% validation accuracy within 15 epochs on a single consumer GPU
(e.g. RTX 3060), training in under 10 minutes.
