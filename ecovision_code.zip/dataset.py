"""
dataset.py — Data loading utilities for EcoVision waste classification.

Expected folder layout (standard torchvision ImageFolder format), e.g. TrashNet
or the Kaggle "Garbage Classification" dataset:

    data/
      train/
        cardboard/  *.jpg
        glass/      *.jpg
        metal/      *.jpg
        paper/      *.jpg
        plastic/    *.jpg
        trash/      *.jpg
      val/
        cardboard/  ...
        ...

If you only have one folder of images, use `split_dataset()` below to create
train/val splits automatically (80/20 by default).
"""

import os
import shutil
import random
from pathlib import Path

import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

# ImageNet normalization stats — required because we fine-tune an
# ImageNet-pretrained backbone (ResNet50).
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

IMG_SIZE = 224


def build_transforms(train: bool):
    if train:
        return transforms.Compose([
            transforms.RandomResizedCrop(IMG_SIZE, scale=(0.7, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ])
    return transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


def get_dataloaders(data_dir: str, batch_size: int = 32, num_workers: int = 4):
    """Returns (train_loader, val_loader, class_names)."""
    train_dir = os.path.join(data_dir, "train")
    val_dir = os.path.join(data_dir, "val")

    if not os.path.isdir(train_dir) or not os.path.isdir(val_dir):
        raise FileNotFoundError(
            f"Expected {train_dir} and {val_dir} to exist. "
            "Run split_dataset() first if you only have a single folder of classes."
        )

    train_ds = datasets.ImageFolder(train_dir, transform=build_transforms(train=True))
    val_ds = datasets.ImageFolder(val_dir, transform=build_transforms(train=False))

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True, drop_last=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True,
    )

    assert train_ds.classes == val_ds.classes, "train/val class folders must match"
    return train_loader, val_loader, train_ds.classes


def split_dataset(source_dir: str, output_dir: str, val_frac: float = 0.2, seed: int = 42):
    """
    Splits a flat `source_dir/<class>/*.jpg` layout into
    `output_dir/train/<class>/` and `output_dir/val/<class>/` by copying files.
    Use this once if your raw dataset isn't already split.
    """
    random.seed(seed)
    source_dir = Path(source_dir)
    output_dir = Path(output_dir)

    classes = [d.name for d in source_dir.iterdir() if d.is_dir()]
    if not classes:
        raise ValueError(f"No class subfolders found in {source_dir}")

    for cls in classes:
        files = list((source_dir / cls).glob("*"))
        files = [f for f in files if f.suffix.lower() in {".jpg", ".jpeg", ".png"}]
        random.shuffle(files)
        n_val = max(1, int(len(files) * val_frac))
        val_files, train_files = files[:n_val], files[n_val:]

        for split_name, split_files in [("train", train_files), ("val", val_files)]:
            dest = output_dir / split_name / cls
            dest.mkdir(parents=True, exist_ok=True)
            for f in split_files:
                shutil.copy2(f, dest / f.name)

        print(f"[{cls}] train={len(train_files)}  val={len(val_files)}")

    print(f"Done. Split dataset written to {output_dir}")
