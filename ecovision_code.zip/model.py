"""
model.py — GPU-accelerated waste classifier built on a pretrained ResNet50
backbone (transfer learning). Swapping BACKBONE below to 'efficientnet_b0' or
'mobilenet_v3_large' trades accuracy for speed if you need faster inference
on edge devices.
"""

import torch
import torch.nn as nn
from torchvision import models


def build_model(num_classes: int, backbone: str = "resnet50", freeze_backbone: bool = True) -> nn.Module:
    if backbone == "resnet50":
        net = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        in_features = net.fc.in_features
        if freeze_backbone:
            for p in net.parameters():
                p.requires_grad = False
        net.fc = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(in_features, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(256, num_classes),
        )
        return net

    if backbone == "efficientnet_b0":
        net = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)
        in_features = net.classifier[1].in_features
        if freeze_backbone:
            for p in net.parameters():
                p.requires_grad = False
        net.classifier = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(in_features, num_classes),
        )
        return net

    if backbone == "mobilenet_v3_large":
        net = models.mobilenet_v3_large(weights=models.MobileNet_V3_Large_Weights.IMAGENET1K_V2)
        in_features = net.classifier[-1].in_features
        if freeze_backbone:
            for p in net.parameters():
                p.requires_grad = False
        net.classifier[-1] = nn.Linear(in_features, num_classes)
        return net

    raise ValueError(f"Unknown backbone: {backbone}")


def unfreeze_last_n_layers(model: nn.Module, n: int = 20):
    """Fine-tuning helper: unfreeze the last N parameter tensors for stage-2 training."""
    params = list(model.parameters())
    for p in params[-n:]:
        p.requires_grad = True
